package com.capgemini.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;



@Controller
public class JspController {

	@RequestMapping("/")
	ModelAndView loadIndex() {
		ModelAndView modelAndView = new ModelAndView("index");
		return modelAndView;
	}
	
	@RequestMapping("/customer-homepage")
	ModelAndView loadCustomerHomepage() {
		ModelAndView modelAndView = new ModelAndView("customer-homepage");
		return modelAndView;
	}
	
	@RequestMapping("/single")
	ModelAndView loadSingle() {
		ModelAndView modelAndView = new ModelAndView("single");
		return modelAndView;
	}
}
